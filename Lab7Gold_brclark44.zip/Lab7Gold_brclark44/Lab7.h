/*
	Title: Lab7.h
	Author: Benjamin Clark
	Date: 3/5/24
	Purpose: Teach 3rd to 6th grade students fun facts about animals. This
    is the header file.
*/
#ifndef LAB7_H
#define LAB7_H

#include <iostream>
using namespace std;

//function prototypes
void test(int&, int);
int menu();

#endif